
<?php $__env->startSection('footer'); ?>
<!-- Begin Footer Area -->
<div class="footer-area" data-bg-image="assets/images/footer/bg/1-1920x465.jpg">
    <div class="footer-top section-space-top-100 pb-60">
      <div class="container">
        <div class="row">
          <div class="col-lg-10">
            <div class="footer-widget-item">
              <div class="footer-widget-logo">
                <a href="index.html">
                  <img src="assets/images/logo/dark.png" alt="Logo">
                </a>
              </div>
              <p class="footer-widget-desc">Lorem ipsum dolor sit amet, consec adipisl elit, sed do eiusmod
                tempor
                <br>
                incidio ut labore et dolore magna.
              </p>
              <div class="social-link with-border">
                <ul>
                  <li>
                    <a href="#" data-tippy="Facebook" data-tippy-inertia="true" data-tippy-animation="shift-away"
                      data-tippy-delay="50" data-tippy-arrow="true" data-tippy-theme="sharpborder">
                      <i class="fa fa-facebook"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#" data-tippy="Twitter" data-tippy-inertia="true" data-tippy-animation="shift-away"
                      data-tippy-delay="50" data-tippy-arrow="true" data-tippy-theme="sharpborder">
                      <i class="fa fa-twitter"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#" data-tippy="Pinterest" data-tippy-inertia="true" data-tippy-animation="shift-away"
                      data-tippy-delay="50" data-tippy-arrow="true" data-tippy-theme="sharpborder">
                      <i class="fa fa-pinterest"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#" data-tippy="Dribbble" data-tippy-inertia="true" data-tippy-animation="shift-away"
                      data-tippy-delay="50" data-tippy-arrow="true" data-tippy-theme="sharpborder">
                      <i class="fa fa-dribbble"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-4 pt-40">
            <div class="footer-widget-item">
              <h3 class="footer-widget-title">Our Service</h3>
              <ul class="footer-widget-list-item">
                <li>
                  <a href="#">Payment Methods</a>
                </li>
                <li>
                  <a href="#">Money Guarantee!</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="copyright">
              <span class="copyright-text">© <?php echo e(date('Y')); ?> Made with <i class="fa fa-heart text-danger"></i> by Me
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer Area End Here -->
<?php $__env->stopSection(); ?>