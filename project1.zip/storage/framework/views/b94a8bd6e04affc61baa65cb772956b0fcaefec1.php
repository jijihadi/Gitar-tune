<!DOCTYPE html>
<html lang="zxx">

<head>

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta name="robots" content="index, follow" />
  <meta name="description"
    content="Pronia plant store bootstrap 5 template is an awesome website template for any home plant shop.">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico" />

  <!-- CSS
    ============================================ -->

  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
  <link rel="stylesheet" href="assets/css/Pe-icon-7-stroke.css" />
  <link rel="stylesheet" href="assets/css/animate.min.css">
  <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
  <link rel="stylesheet" href="assets/css/nice-select.css">
  <link rel="stylesheet" href="assets/css/magnific-popup.min.css" />
  <link rel="stylesheet" href="assets/css/ion.rangeSlider.min.css" />

  <!-- Style CSS -->
  <link rel="stylesheet" href="assets/css/style.css">

</head>

<body style="background: url('assets/images/banner/5-1-1980-1080.jpg'); background-size:cover">
  <div class="preloader-activate preloader-active open_tm_preloader">
    <div class="preloader-area-wrap">
      <div class="spinner d-flex justify-content-center align-items-center h-100">
        <div class="bounce1"></div>
        <div class="bounce2"></div>
        <div class="bounce3"></div>
      </div>
    </div>
  </div>
  <div class="main-wrapper">

    <?php echo $__env->yieldContent('container'); ?>

  </div>

  <!-- Global Vendor, plugins JS -->

  <!-- JS Files
    ============================================ -->

  <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
  <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
  <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
  <script src="assets/js/vendor/jquery.waypoints.js"></script>
  <script src="assets/js/vendor/modernizr-3.11.2.min.js"></script>
  <script src="assets/js/plugins/wow.min.js"></script>
  <script src="assets/js/plugins/swiper-bundle.min.js"></script>
  <script src="assets/js/plugins/jquery.nice-select.js"></script>
  <script src="assets/js/plugins/parallax.min.js"></script>
  <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/plugins/tippy.min.js"></script>
  <script src="assets/js/plugins/ion.rangeSlider.min.js"></script>
  <script src="assets/js/plugins/mailchimp-ajax.js"></script>
  <script src="assets/js/plugins/jquery.counterup.js"></script>

  <!--Main JS (Common Activation Codes)-->
  <script src="assets/js/main.js"></script>

</body>

</html>
