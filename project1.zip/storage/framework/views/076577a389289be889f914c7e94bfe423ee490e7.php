<?php $__env->startSection('title', 'Web'); ?>



<?php $__env->startSection('container'); ?>
<!-- Begin Slider Area -->
<div class="slider-area">
    <!-- Main Slider -->
    <div class="swiper-container main-slider-2 swiper-arrow with-bg_white">
        <div class="swiper-wrapper">
            <div class="swiper-slide animation-style-02">
                <div class="slide-inner style-2" data-bg-image="assets/images/slider/bg/2-1.jpg">
                    <div class="slide-content text-black">
                        <h2 class="title">Stem <br> Your Guitar</h2>
                        <p class="short-desc">With various version and alto.</p>
                        <div class="btn-wrap">
                            <a class="btn btn-custom-size xl-size btn-pronia-primary" href="<?php echo e(url('/stem')); ?>">Discover Now</a>
                        </div>
                    </div>
                    <div class="slide-img">
                        <img src="assets/images/slider/slide-img/2-1-960x741.jpg" alt="Slide Image">
                        <div class="slide-count">
                            <span class="data-count" data-count="01">
                                <span class="forward-slash">/</span>
                                <span>01</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- Add Arrows -->
        <div class="slide-button-wrap">
            <div class="slide-button-prev">
                <i class="pe-7s-angle-left"></i>
            </div>
            <div class="slide-button-next">
                <i class="pe-7s-angle-right"></i>
            </div>
        </div>
    </div>

</div>
<!-- Slider Area End Here -->

<!-- Begin Banner Area -->

<!-- Banner Area End Here -->

<!-- Begin about Area -->
<div class="about-area section-space-top-95 mb-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="about-content">
                    <h2 class="about-title">What is <span> GIM?</span></h2>
                    <p class="about-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                        exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                        in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur
                        sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
                        laborum. Sed ut perspiciatis</p>
                    <div class="about-signature">
                        <img src="assets/images/about/icon/2.png" alt="Signature">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End about Area -->

<!-- Begin Banner Area -->
<div class="banner-area mb-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="banner-bg-image img-hover-effect" data-bg-image="assets/images/banner/4-1-1170x400.jpg">
                    <div class="inner-content">
                        
                        
                        <h3 class="discount text-white">Tune up your <span>guitar</span></h3>
                        <div class="button-wrap">
                            <a class="btn btn-custom-size btn-pronia-primary" href="<?php echo e(url('/stem')); ?>">Now!</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Banner Area End Here -->

<!-- Testimonial Area End Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>