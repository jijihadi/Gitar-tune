<?php if(\Route::current()->getName()=='users.edit'): ?>
    <?php $__env->startSection('title', 'Edit User | Gim'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Add User | Gim'); ?>
<?php endif; ?>

<?php 
    $id = "";
    $nama = "";
    $email = "";
    $password = "";
    $role_as = "";
 ?>
<?php if(!empty($post)): ?>:
    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
        <?php 
            $id = $post->id;
            $nama = $post->name;
            $email = $post->email;
            $password = $post->password;
            $role_as = $post->role_as;
         ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->startSection('container'); ?>
<section id="dashboard-analytics">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(url('/users')); ?>" class="text-right btn btn-relief-secondary"> <i
                            class="feather icon-chevrons-left"></i>back</a>
                </div>
                <div class="card-content">
                    <div class="card-body card-dashboard">
                        
                        <div>
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4">
                                <div class="col-lg-12">
                                    <?php if($errors->any()): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($error); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true"><i class="feather icon-x-circle"></i></span>
                                        </button>
                                    </div>
                                    <?php endif; ?>
                                    <div class="col-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <?php if(Route::current()->getName()=='users.add'): ?>
                                                <h4 class="card-title">Add Master User</h4>
                                                <?php endif; ?>
                                                <?php if(Route::current()->getName()=='users.edit'): ?>
                                                <h4 class="card-title">Edit User <?php echo e($nama); ?> </h4>
                                                <?php endif; ?>
                                            </div>
                                            <div class="card-content">
                                                <div class="card-body">
                                                    <?php if(Route::current()->getName()=='users.add'): ?>
                                                    <form action="<?php echo e(route('users.insert')); ?>" method="POST"
                                                        role="form" enctype="multipart/form-data" 
                                                        class="form form-horizontal">
                                                        <?php endif; ?>
                                                        <?php if(Route::current()->getName()=='users.edit'): ?>
                                                        <form action="<?php echo e(route('users.update',$id)); ?>" method="POST"
                                                        role="form" enctype="multipart/form-data" 
                                                            class="form form-horizontal">
                                                            <?php endif; ?>
                                                            <?php echo e(csrf_field()); ?>

                                                            <div class="form-body">
                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <div class="form-group row">
                                                                            <div class="col-md-4">
                                                                                <span>Nama User</span>
                                                                            </div>
                                                                            <div class="col-md-8">
                                                                                <div
                                                                                    class="position-relative has-icon-left">
                                                                                    <input type="text" id="fname-icon"
                                                                                        value="<?php echo e($nama); ?>"
                                                                                        class="form-control" name="name"
                                                                                        placeholder="Nama User">
                                                                                    <div class="form-control-position">
                                                                                        <i
                                                                                            class="feather icon-user"></i>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <div class="form-group row">
                                                                            <div class="col-md-4">
                                                                                <span>E-mail</span>
                                                                            </div>
                                                                            <div class="col-md-8">
                                                                                <div
                                                                                    class="position-relative has-icon-left">
                                                                                    <input type="email" id="fname-icon"
                                                                                        value="<?php echo e($email); ?>"
                                                                                        class="form-control" name="email"
                                                                                        placeholder="Email">
                                                                                    <div class="form-control-position">
                                                                                        <i
                                                                                            class="feather icon-at-sign"></i>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <div class="form-group row">
                                                                            <div class="col-md-4">
                                                                                <span>Password</span>
                                                                            </div>
                                                                            <div class="col-md-8">
                                                                                <div
                                                                                    class="position-relative has-icon-left">
                                                                                    <input type="password" id="fname-icon"
                                                                                        class="form-control" name="password"
                                                                                        placeholder="Password">
                                                                                    <div class="form-control-position">
                                                                                        <i
                                                                                            class="feather icon-lock"></i>
                                                                                    </div>
                                                                                    <small class="text-danger">*Kosongi password jika tidak ingin merubah password.</small>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <div class="form-group row">
                                                                            <div class="col-md-4">
                                                                                <span>Jenis</span>
                                                                            </div>
                                                                            <div class="col-md-8">
                                                                                <select class="select2 form-control"
                                                                                    name="role_as">
                                                                                    <option value="-">Pilih Jenis User
                                                                                    </option>
                                                                                    <option value="1">Admin</option>
                                                                                    <option value="0">Pengunjung</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12 ">
                                                                        <button type="submit"
                                                                            class="btn btn-relief-primary col-12 waves-effect waves-light">Submit</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>