<?php $__env->startSection('title', 'Gitar | Gim'); ?>



<?php $__env->startSection('container'); ?>
<!-- Dashboard Analytics Start -->
<section id="dashboard-analytics">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><i class="feather icon-music"></i> Data Master Gitar</h4>
                    <a href="<?php echo e(url('/gitars/add')); ?>" class="text-right btn btn-relief-success"> <i class="feather icon-plus"></i>Tambah</a>
                </div>
                <?php if(session('success_msg')!=''): ?>
                    <div class="col-12 mt-2">
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success_msg')); ?> 
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="feather icon-x-circle"></i></span>
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="card-content">
                    <div class="card-body card-dashboard">
                        
                        <div>
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-stripped" id="myTable" role="grid"
                                            aria-describedby="DataTables_Table_0_info">
                                            <thead>
                                                <tr role="row">
                                                    
                                                    <th>#</th>
                                                    <th>Nama</th>
                                                    <th>Jenis</th>
                                                    <th>Merk</th>
                                                    <th>Harga</th>
                                                    <th>Gambar</th>
                                                    <th>#</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(!$gitar->isEmpty()): ?>
                                                <?php $__currentLoopData = $gitar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr role="row">
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td class="sorting_1"><?php echo e($g->nama); ?></td>
                                                    <td><?php echo e(namanya('jeniss', $g->jenis)); ?></td>
                                                    <td><?php echo e(namanya('merks', $g->merk)); ?></td>
                                                    <td><?php echo e(rupiah($g->harga)); ?></td>
                                                    <td><img src="<?php echo e(url('/')); ?>/file_upload/img/<?php echo e($g->gambar); ?>" alt="avatar" height="100" width="100"></td>
                                                    <td>
                                                        <a href="<?php echo e(route('gitars.edit', $g->id_gitar)); ?>"
                                                            class="btn btn-icon btn-warning mr-1 mb-1 waves-effect waves-light">
                                                            <i class="feather icon-edit-1"></i></a>
                                                        <a  onclick="return confirm('Hapus data <?php echo e($g->nama); ?>')"  href="<?php echo e(route('gitars.delete', $g->id_gitar)); ?>"
                                                            class="btn btn-icon btn-danger mr-1 mb-1 waves-effect waves-light">
                                                            <i class="feather icon-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                <tr role="row">
                                                    <td colspan="7" class="text-center">Data Masih Kosong</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Nama</th>
                                                    <th>Jenis</th>
                                                    <th>Merk</th>
                                                    <th>Harga</th>
                                                    <th>Gambar</th>
                                                    <th>#</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>