<?php $__env->startSection('title', 'User | Gim'); ?>



<?php $__env->startSection('container'); ?>
<!-- Dashboard Analytics Start -->
<section id="dashboard-analytics">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><i class="feather icon-music"></i> Data Master User</h4>
                    <a href="<?php echo e(url('/users/add')); ?>" class="text-right btn btn-relief-success"> <i class="feather icon-plus"></i>Tambah</a>
                </div>
                <?php if(session('success_msg')!=''): ?>
                    <div class="col-12 mt-2">
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success_msg')); ?> 
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="feather icon-x-circle"></i></span>
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="card-content">
                    <div class="card-body card-dashboard">
                        
                        <div>
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-stripped" id="myTable" role="grid"
                                            aria-describedby="DataTables_Table_0_info">
                                            <thead>
                                                <tr role="row">
                                                    
                                                    <th>#</th>
                                                    <th>Nama</th>
                                                    <th>Email</th>
                                                    <th>Hak Akses</th>
                                                    <th>Tanggal Daftar</th>
                                                    <th>#</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(!$user->isEmpty()): ?>
                                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr role="row">
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td class="sorting_1"><?php echo e($g->name); ?></td>
                                                    <td><?php echo e($g->email); ?></td>
                                                    <td><?php echo e(aksesnya($g->role_as)); ?></td>
                                                    <td><?php echo e(tgl_indo($g->created_at)); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route('users.edit', $g->id)); ?>"
                                                            class="btn btn-icon btn-warning mr-1 mb-1 waves-effect waves-light">
                                                            <i class="feather icon-edit-1"></i></a>
                                                        <a  onclick="return confirm('Hapus data <?php echo e($g->name); ?>')"  href="<?php echo e(route('users.delete', $g->id)); ?>"
                                                            class="btn btn-icon btn-danger mr-1 mb-1 waves-effect waves-light">
                                                            <i class="feather icon-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                <tr role="row">
                                                    <td colspan="7" class="text-center">Data Masih Kosong</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Nama</th>
                                                    <th>Email</th>
                                                    <th>Hak Akses</th>
                                                    <th>Tanggal Daftar</th>
                                                    <th>#</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>