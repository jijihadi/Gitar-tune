<?php if(\Route::current()->getName()=='merk.add'): ?>
    <?php $__env->startSection('title', 'Add Merk | Gim'); ?>
<?php elseif(\Route::current()->getName()=='jenis.add'): ?>
    <?php $__env->startSection('title', 'Add Jenis | Gim'); ?>
<?php elseif(\Route::current()->getName()=='merk.edit'): ?>
    <?php $__env->startSection('title', 'Edit Merk | Gim'); ?>
<?php elseif(\Route::current()->getName()=='jenis.edit'): ?>
    <?php $__env->startSection('title', 'Edit Jenis | Gim'); ?>
<?php endif; ?>

<?php 
    $id = "";
    $nama = "";
 ?>

<?php if(!empty($merk)): ?>:
    <?php $__currentLoopData = $merk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
        <?php 
            $id = $merk->id_merk;
            $nama = $merk->nama_merk;
         ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(!empty($jenis)): ?>:
    <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
        <?php 
            $id = $jenis->id_jenis;
            $nama = $jenis->nama_jenis;
         ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->startSection('container'); ?>
<section id="dashboard-analytics">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(url('/merjen')); ?>" class="text-right btn btn-relief-secondary"> <i
                            class="feather icon-chevrons-left"></i>back</a>
                </div>
                <div class="card-content">
                    <div class="card-body card-dashboard">
                        
                        <div>
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4">
                                <div class="col-lg-12">
                                    <?php if($errors->any()): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($error); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true"><i class="feather icon-x-circle"></i></span>
                                        </button>
                                    </div>
                                    <?php endif; ?>
                                    <div class="col-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <?php if(\Route::current()->getName()=='merk.add'): ?>
                                                    <h4 class="card-title">Add Merk </h4>
                                                <?php elseif(\Route::current()->getName()=='jenis.add'): ?>
                                                    <h4 class="card-title">Add Jenis </h4>
                                                <?php elseif(\Route::current()->getName()=='merk.edit'): ?>
                                                    <h4 class="card-title">Edit Merk <?php echo e($nama); ?> </h4>
                                                <?php elseif(\Route::current()->getName()=='jenis.edit'): ?>                                                
                                                    <h4 class="card-title">Edit Jenis <?php echo e($nama); ?> </h4>
                                                <?php endif; ?>
                                            </div>
                                            <div class="card-content">
                                                <div class="card-body">
                                                    <?php if(\Route::current()->getName()=='merk.add'): ?>
                                                        <form action="<?php echo e(route('merk.insert')); ?>" method="POST"
                                                            role="form" enctype="multipart/form-data"
                                                            class="form form-horizontal">
                                                    <?php elseif(\Route::current()->getName()=='jenis.add'): ?>
                                                        <form action="<?php echo e(route('jenis.insert')); ?>" method="POST"
                                                            role="form" enctype="multipart/form-data"
                                                            class="form form-horizontal">
                                                    <?php elseif(\Route::current()->getName()=='merk.edit'): ?>
                                                        <form action="<?php echo e(route('merk.update',$id)); ?>" method="POST"
                                                            role="form" enctype="multipart/form-data"
                                                            class="form form-horizontal">
                                                    <?php elseif(\Route::current()->getName()=='jenis.edit'): ?>                                                
                                                        <form action="<?php echo e(route('jenis.update',$id)); ?>" method="POST"
                                                            role="form" enctype="multipart/form-data"
                                                            class="form form-horizontal">
                                                    <?php endif; ?>
                                                            <?php echo e(csrf_field()); ?>

                                                            <div class="form-body">
                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <div class="form-group row">
                                                                            <?php if(\Route::current()->getName()=='merk.add'||\Route::current()->getName()=='merk.edit'): ?>
                                                                            <div class="col-md-4">
                                                                                <span>Nama Merk</span>
                                                                            </div>
                                                                            <div class="col-md-8">
                                                                                <div
                                                                                    class="position-relative has-icon-left">
                                                                                    <input type="text" id="fname-icon"
                                                                                        value="<?php echo e($nama); ?>"
                                                                                        class="form-control" name="nama_merk"
                                                                                        placeholder="Nama Merk">
                                                                                    <div class="form-control-position">
                                                                                        <i
                                                                                            class="feather icon-tag"></i>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <?php elseif(\Route::current()->getName()=='jenis.add'||\Route::current()->getName()=='jenis.edit'): ?>
                                                                            <div class="col-md-4">
                                                                                <span>Nama Jenis</span>
                                                                            </div>
                                                                            <div class="col-md-8">
                                                                                <div
                                                                                    class="position-relative has-icon-left">
                                                                                    <input type="text" id="fname-icon"
                                                                                        value="<?php echo e($nama); ?>"
                                                                                        class="form-control" name="nama_jenis"
                                                                                        placeholder="Nama Jenis">
                                                                                    <div class="form-control-position">
                                                                                        <i
                                                                                            class="feather icon-tag"></i>
                                                                                    </div>
                                                                                </div>
                                                                            </div>  
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12 ">
                                                                        <button type="submit"
                                                                            class="btn btn-relief-primary col-12 waves-effect waves-light">Submit</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>