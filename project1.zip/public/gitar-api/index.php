<!DOCTYPE html>
<html>
<head>
    <title>Tutorial Nodejs</title>
</head>
<body>
    <h1>Selamat datang di Tutorial Nodejs Petanikode</h1>
    <p>Hello, kita sedang belajar tentang modul URL</p>
</body>
</html>